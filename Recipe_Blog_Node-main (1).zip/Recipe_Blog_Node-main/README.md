
# Recipe Blog - Using Node.js,Ejs and MongoDB

## Installation
$ npm install

$ npm start









